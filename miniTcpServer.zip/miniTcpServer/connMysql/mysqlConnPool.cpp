#include "mysqlConnPool.h"

using namespace std;

connection_pool::connection_pool(){
	m_FreeConn = 0;
	m_CurConn = 0;
}

connection_pool* connection_pool::GetInstance(){
	static connection_pool connPool;
	return &connPool;
}

void connection_pool::init(string url, int port, string user, string password, string database, int MaxConn){
	m_url = url;
	m_port = port;
	m_user = user;
	m_password = password;
	m_databaseName = database;
	m_filename = "../Logs/dblog";
	int _Maxconn = 8;
	
	for(int i = 0; i < 8; i++){
		MYSQL* conn = NULL;
		conn = mysql_init(conn);
		if(conn == NULL){
			//printf("init %dmysqlconn failed\n",i);
			m_log.logOpen(m_filename.c_str());
			m_log.logWrite("MYSQL ERROR");
			exit(1);
		}
		conn = mysql_real_connect(conn, url.c_str(), user.c_str(), password.c_str(), database.c_str(), port, NULL, 0);
		if(conn == NULL){
			//printf("real connect mysql failed%d\n",i);
			m_log.logOpen(m_filename.c_str());
			m_log.logWrite("MYSQL ERROR");
			exit(1);
		}
		connList.push_back(conn);
		++m_FreeConn;
	}
	//printf("\nm_FreeConn=%d\n", m_FreeConn);
	m_MaxConn = m_FreeConn;
	reserve = sem(m_FreeConn);
}

connection_pool::~connection_pool(){
	destroyPool();
}

MYSQL* connection_pool::getConnection(){
	MYSQL* conn = NULL;
	if(connList.size()<=0){
		return NULL;
	}

	reserve.wait();
	lock.lock();
	conn = connList.front();
	connList.pop_front();
	lock.unlock();

	--m_FreeConn;
	++m_CurConn;
	return conn;
}

bool connection_pool::releaseConnection(MYSQL* conn){
	if(conn == NULL){
		return false;
	}

	lock.lock();
	connList.push_back(conn);
	lock.unlock();
	reserve.post();

	++m_FreeConn;
	--m_CurConn;
	return true;
}

void connection_pool::destroyPool(){
	lock.lock();
	if(connList.size()>0){
		list<MYSQL*>::iterator i;
		for(i = connList.begin(); i != connList.end();i++){
			MYSQL* conn = *i;
			mysql_close(conn);
		}
		m_CurConn = 0;
		m_FreeConn = 0;
		connList.clear();
	}
	lock.unlock();
}

int connection_pool::getFreeConn(){
	return m_FreeConn;
}

connectionRAII::connectionRAII(MYSQL* mysql, connection_pool* connPool){
	mysql = connPool->getConnection();
	conRAII = mysql;
	poolRAII = connPool;
}

connectionRAII::~connectionRAII(){
	poolRAII->releaseConnection(conRAII);
}

		

















