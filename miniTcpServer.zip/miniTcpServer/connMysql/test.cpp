#include "../TcpServer/server.h"

int main(){
	
	connection_pool* m_pool = connection_pool::GetInstance();
	m_pool->init("127.0.0.1", 3306, "root", "piiaJet0802","testdb",8);

	threadpool* tp = new threadpool(m_pool);
	string str = "<bizcode>0</bizcode><Sno>12</Sno><Sname>ppipi</Sname><Sage>14</Sage><Sdept>CS</Sdept>";
	tp->append(str);

	sleep(1);
	
}




