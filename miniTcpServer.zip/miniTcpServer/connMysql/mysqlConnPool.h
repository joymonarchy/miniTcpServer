#ifndef CONNECTION_POOL
#define CONNECTION_POOL

#include <stdio.h>
#include <list>
#include <mysql/mysql.h>
#include <error.h>
#include <string.h>
#include <iostream>
#include <string>
#include "../lock/locker.h"
#include "../log/log.h"

using namespace std;

class connection_pool{
private:
	int m_MaxConn;
	int m_CurConn;
	int m_FreeConn;
	list<MYSQL*> connList;
	sem reserve;
	locker lock;
	Log m_log;
	string m_filename;
	~connection_pool();
	connection_pool();

public:
	string m_url;
	string m_port;
	string m_user;
	string m_password;
	string m_databaseName;
	//int m_close_log;
	static connection_pool *GetInstance();

	void init(string url, int port, string user, string password, string database, int MaxConn);
	bool releaseConnection(MYSQL* conn);
	MYSQL* getConnection();
	int getFreeConn();
	void destroyPool();
};

class connectionRAII{
private:
	MYSQL* conRAII;
	connection_pool* poolRAII;
public:
	connectionRAII(MYSQL* con, connection_pool* connPool);
	~connectionRAII();
};



#endif
