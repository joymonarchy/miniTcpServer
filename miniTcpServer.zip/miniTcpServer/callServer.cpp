#include "TcpServer/server.h"

int main(){
	TcpServer server;

	server.sql_pool();
	server.thread_pool();
	
	
	server.eventListen();
	server.eventLoop();

	return 0;
}
