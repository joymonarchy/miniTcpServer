#ifndef THREADPOOL_H
#define THREADPOOL_H

#include <iostream>
#include <list>
#include <assert.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <exception>
#include "../lock/locker.h"
#include "../log/log.h"
#include "../tool/tool.h"
#include "../connMysql/mysqlConnPool.h"
//#include <string>
//using namespace std;

class threadpool{
private:
	int m_thread_num;
	int m_max_request;
	pthread_t* m_threads;
	std::list<std::string> m_workqueue;
	sem m_queuestat;
	locker m_queuelocker;
	connection_pool* m_connPool;
	Log m_log;
	char m_filename[40];

	static void* worker(void* arg);
	void run();
	void _main(char* request);
	void biz000(char* request);

public:
	//threadpool(int tn=8, int mr=10000);
	~threadpool();
	threadpool(connection_pool* cp, int tn=8, int mr=10000);
	bool append(std::string request);

};

#endif
