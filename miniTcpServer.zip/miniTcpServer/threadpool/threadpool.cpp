#include "threadpool.h"


threadpool::threadpool(connection_pool* cp, int tn, int mr):m_connPool(cp),m_thread_num(tn),m_max_request(mr){
	memset(m_filename, 0, sizeof(m_filename));
	sprintf(m_filename, "../Logs/threadsLog");
//	printf("threadpool m_filename:%s\n", m_filename);
	if(m_thread_num <= 0 || m_max_request <= 0){
		throw std::exception();
	}
	m_threads = new pthread_t[m_thread_num];
	if(m_threads == NULL){
		throw std::exception();
	}
	for(int i = 0; i < m_thread_num;i++){
		if( pthread_create(m_threads+i, NULL, worker, this) != 0){
			delete[] m_threads;
			throw std::exception();
		}
		if( pthread_detach(m_threads[i]) != 0){
			delete[] m_threads;
			throw std::exception();
		}
	}
}

threadpool::~threadpool(){
	delete[] m_threads;
}

bool threadpool::append(std::string request){
	m_queuelocker.lock();
	if( m_workqueue.size() >= m_max_request){
		m_queuelocker.unlock();
		return false;
	}
	m_workqueue.push_back(request);
	m_queuelocker.unlock();
	m_queuestat.post();
	return true;
}

void* threadpool::worker(void* arg){
	threadpool* pool = (threadpool*)arg;
	pool->run();
	return pool;
}

void threadpool::run(){
	while(1){
		m_queuestat.wait();
		m_queuelocker.lock();
		if(m_workqueue.size() <= 0){
			m_queuelocker.unlock();
			continue;
		}
		std::string srequest = m_workqueue.front();
		m_workqueue.pop_front();
		//printf("%s", srequest.c_str());
		m_queuelocker.unlock();
		char request[1024];
		memset(request, 0, sizeof(request));
		sprintf(request, "%s", srequest.c_str());
		_main(request);
		/*
		 * do things.
		 * _main(char* request);
		 * _main(srequest.c_str());
		 */
	}
}

char* instructions[] = {"bizcode","Sno", "Sname", "Sage", "Sdept","socket","retcode", "message"};
//void biz000(char* request);//add
void biz001(char* request);//delete
void biz002(char* request);//alter
void biz003(char* request);//select


void threadpool::_main(char* request){
	char sbizcode[5];
	//printf("request:%s\n");
	memset(sbizcode, 0,sizeof(sbizcode));
	unzipXML(request, instructions[0], sbizcode);
	char bizcode = sbizcode[0];
	//printf("%c\n", bizcode);
	switch (bizcode){
		case '0':biz000(request);
				 break;
				 /*
		case '1':biz001(request);
				 break;
		case '2':biz002(request);
				 break;
		case '3':biz003(request);
				 break;
				 */
		default:{
				m_log.logOpen(m_filename);
				m_log.logWrite("ILLEGAL INSTRUCTION\n");
				return;
				}
	}
}

//add
void threadpool::biz000(char* request){
	//mysql Connect
	MYSQL* conn = m_connPool->getConnection();
	connectionRAII(conn, m_connPool);
	//unzip XML message and do mysql_query
	char query[1024];
	memset(query, 0, sizeof(query));
	sprintf(query, "insert into student values (");
	char value[20];
	for(int i = 1; i < 5; i++){
		memset(value, 0, sizeof(value));
		unzipXML(request, instructions[i], value);
		if(i>1) strcat(query,",");
		
		strcat(query,"'");
		strcat(query, value);
		strcat(query,"'");
	}
	strcat(query,");");

	memset(value, 0, sizeof(value));
	unzipXML(request, instructions[5], value);
	int sockfd = atoi(value);

	
	char sendbuf[1024];
	char tmpstr[256];
	memset(sendbuf, 0, sizeof(sendbuf));

	if(mysql_query(conn, query) != 0){
		m_log.logOpen(m_filename);
		m_log.logWrite("DATABASE WRITE ERROR\n");
		sprintf(sendbuf,"<retcode>0</retcode>");
		if( send(sockfd, sendbuf, sizeof(sendbuf), 0) <= 0){
			m_log.logWrite("SEND ERROR ERROR!\n");
		}
		return;
	}
	if(!m_log.logOpen(m_filename)){
		printf("threadpool biz000 fileopen failed!\n");
	}
	if(!m_log.logWrite("DATABASE WRITE OK\n")){
		printf("threadpool biz000 filewrite failed\n");
	}
	//send ok message
	

	memset(tmpstr, 0 , sizeof(tmpstr));
	zipXML(tmpstr,instructions[6],"1");
	strcat(sendbuf, tmpstr);
	memset(tmpstr, 0, sizeof(tmpstr));
	zipXML(tmpstr, instructions[7], "write ok");
	strcat(sendbuf, tmpstr);
	if( send(sockfd, sendbuf, sizeof(sendbuf), 0) <= 0){
		m_log.logWrite("SEND OK ERROR!\n");

	}
}


void biz001(char* request){}

void biz002(char* request){}

void biz003(char* request){}











