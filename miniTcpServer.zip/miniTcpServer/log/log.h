#ifndef LOG_H
#define LOG_H

#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include "../tool/tool.h"

class Log{
public:
	FILE* m_tracefp;
	char m_filename[301];
	char m_openmode[11];

	void logClose();
public:
	Log();
	bool logOpen(const char* filename, const char* openmode=0);
	bool logWrite(const char* format, ...);
	bool logWriteEx(const char* format, ...);


	~Log();
};

#endif
