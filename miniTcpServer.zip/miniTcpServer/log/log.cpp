#include "log.h"
Log::Log(){
	m_tracefp = 0;
	memset(m_filename, 0, sizeof(m_filename));
	memset(m_openmode, 0, sizeof(m_openmode));
}

Log::~Log(){
	logClose();
}

bool Log::logOpen(const char* filename, const char* openmode){
	logClose();
	strcpy(m_filename, filename);
	if(openmode == 0) 
		strcpy(m_openmode, "a+");
	else
		strcpy(m_openmode, openmode);

	m_tracefp = fopen(m_filename, m_openmode);
	if(m_tracefp == 0) return false;
	//printf("open ok!\n");
	return true;
}


bool Log::logWrite(const char* format, ...){
	if(m_tracefp == 0){
		printf("m_tracefp == 0\n");
		return false;
	}
	char strTime[256];
	memset(strTime, 0, sizeof(strTime));
	getPresentTime(strTime);
	va_list ap;
	va_start(ap, format);
	fprintf(m_tracefp, "%s ",strTime);
	vfprintf(m_tracefp, format, ap);
	va_end(ap);
	//printf("write ok!");
	return true;
}

bool Log::logWriteEx(const char* format, ...){
	if(m_tracefp == 0){
		return false;
	}
	va_list ap;
	va_start(ap, format);
	fprintf(m_tracefp, format, ap);
	va_end(ap);

	return true;
}



void Log::logClose(){
	if(m_tracefp != 0){
		fclose(m_tracefp);
		m_tracefp = 0;
	}
	memset(m_filename, 0, sizeof(m_filename));
	memset(m_openmode, 0, sizeof(m_openmode));
}
