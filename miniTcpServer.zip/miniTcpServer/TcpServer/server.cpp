#include "server.h"



bool InitServer(int &sockfd, int port){
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	struct sockaddr_in servaddr;
	servaddr.sin_port = htons(port);
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	
	if( bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) != 0){
		close(sockfd);
		return false;
	}

	if( listen(sockfd, 5) != 0){
		close(sockfd);
		return false;
	}
	return true;
}

int Accept(const int& listenfd){
	return accept(listenfd, 0, 0);
}

int Send(const int&sockfd, const char* buffer, size_t ibuflen){
	return send(sockfd, buffer, ibuflen, 0);
}

int Recv(const int &sockfd,  char* buffer ,size_t ibuflen){
	return recv(sockfd, buffer, ibuflen, 0);
}

void TcpServer::init(){
	m_pool = NULL;
	m_connPool = NULL;
	m_listenfd = 0;
	m_sql_num = 8;
	m_thread_num = 8;
	memset(m_filename, 0, sizeof(m_filename));
	sprintf(m_filename, "../Logs/serverLog");
}

TcpServer::TcpServer(){

}

TcpServer::~TcpServer(){
	close(m_epollfd);
	close(m_listenfd);
	delete m_pool;
}

void TcpServer::sql_pool(){
	m_connPool = connection_pool::GetInstance();
	m_connPool->init("127.0.0.1",3306, "root", "piiaJet0802", "testdb",m_sql_num);
}

void TcpServer::thread_pool(){
	m_pool = new threadpool(this->m_connPool);
}

void TcpServer::eventListen(){
	if(InitServer(m_listenfd, 5005) == false){
		printf("wrong init\n");
		assert(false);
	}
	m_log.logOpen(m_filename);
	m_log.logWrite("Start Listening..\n");

	struct epoll_event events[MAX_EVENT_NUMBER];
	m_epollfd = epoll_create(1);
	assert(m_epollfd != -1);
	struct epoll_event ev;
	ev.data.fd = m_listenfd;
	ev.events = EPOLLIN;
	epoll_ctl(m_epollfd, EPOLL_CTL_ADD, m_listenfd, &ev);
}

void TcpServer::eventLoop(){
	struct epoll_event ev;

	while(1){
		int infds = epoll_wait(m_epollfd, events, MAX_EVENT_NUMBER,-1);
		if(infds <= 0){
			m_log.logOpen(m_filename);
			m_log.logWrite("EPOLL_WAIT FAILED\n");
			break;
		}
		for(int i = 0; i<infds; i++){
			//client connect
			if((events[i].data.fd == m_listenfd) &&(events[i].events & EPOLLIN)){
				int clientfd = Accept(m_listenfd);
				if(clientfd < 0){
					m_log.logOpen(m_filename);
					m_log.logWrite("ACCEPT FAILED\n");
					continue;
				}
				memset(&ev, 0, sizeof(struct epoll_event));
				ev.data.fd = clientfd;
				ev.events = EPOLLIN;
				epoll_ctl(m_epollfd, EPOLL_CTL_ADD, clientfd, &ev);
				m_log.logOpen(m_filename);
				m_log.logWrite("client(socket=%d) connect ok\n",clientfd);
				continue;
			}
			else if(events[i].events & EPOLLIN){
				char buffer[1024];
				memset(buffer, 0, sizeof(buffer));

				if(Recv(events[i].data.fd, buffer, sizeof(buffer))<=0){
					m_log.logOpen(m_filename);
					m_log.logWrite("client(eventfd=%d) disconnected\n",events[i].data.fd);
					memset(&ev, 0, sizeof(struct epoll_event));
					ev.events = EPOLLIN;
					ev.data.fd = events[i].data.fd;
					epoll_ctl(m_epollfd, EPOLL_CTL_DEL, events[i].data.fd, &ev);
					close(events[i].data.fd);
					continue;
				}
				m_pool->append(buffer);
			}
		}
	}
}





	
















