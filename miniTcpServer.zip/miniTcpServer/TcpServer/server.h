#ifndef SERVER_H
#define SERVER_H

#include <stdio.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/epoll.h>

#include "../threadpool/threadpool.h"
#include "../connMysql/mysqlConnPool.h"

const int MAX_EVENT_NUMBER = 10000;

bool InitServer(int &sockfd, int port);
int Accept(const int & listenfd);
int Send(const int &sockfd, const char* buffer, size_t ibuflen);
int Recv(const int &sockfd, char* buffer, size_t ibuflen);

class TcpServer{
public:
	int m_epollfd;
	char m_filename[40];
	Log m_log;

	connection_pool* m_connPool;
	int m_sql_num;

	threadpool* m_pool;
	int m_thread_num;

	epoll_event events[MAX_EVENT_NUMBER];
	int m_listenfd;
public:
	TcpServer();
	~TcpServer();
	void init();
	void thread_pool();
	void sql_pool();
	void eventListen();
	void eventLoop();
};


/*
bool InitServer(int &sockfd, int port){
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	struct sockaddr_in servaddr;
	servaddr.sin_port = htons(port);
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	
	if( bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) != 0){
		close(sockfd);
		return false;
	}

	if( listen(sockfd, 5) != 0){
		close(sockfd);
		return false;
	}
	return true;
}

int Accept(const int& listenfd){
	return accept(listenfd, 0, 0);
}

int Send(const int&sockfd, const char* buffer, size_t ibuflen){
	return send(sockfd, buffer, ibuflen, 0);
}

int Recv(const int &sockfd,  char* buffer ,size_t ibuflen){
	return recv(sockfd, buffer, ibuflen, 0);
}
*/
//bool tcpWrite(const int& sockfd, const char* buffer, const size_t ibuflen);
//bool tcpRead(const int& sockfd, char* buffer,size_t ibuflen);







#endif
