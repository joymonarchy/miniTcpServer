#ifndef CLIENT_H
#define CLIENT_H

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>


bool connectToServer(int &sockfd, const char* serverip, const int port){
	sockfd = socket(AF_INET, SOCK_STREAM, 0);

	struct hostent* h;
	if((h = gethostbyname(serverip)) == 0){
		close(sockfd);
		return false;
	}
	struct sockaddr_in servaddr;

	memset(&servaddr, 0, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(port);
	memcpy(&servaddr.sin_addr, h->h_addr, h->h_length);

	if(connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) != 0){
		close(sockfd);
		return false;
	}
	return true;
}

int Send(int sockfd, const void* buffer, const int buflen){
	return send(sockfd, buffer, buflen, 0);
}

int Recv(int sockfd, void* buffer, int buflen){
	return recv(sockfd, buffer, buflen, 0);
}

#endif

