#include "client.h"
#include "../tool/tool.h"

int clientfd;
char* instructions[] = {"bizcode", "Sno", "Sname", "Sage", "Sdept", "socket", "retcode", "message"};

void printMenu();
void biz000();
void biz001();
void biz002();
void biz003();

int main(){
	//int clientfd;
	while(1){
		printMenu();
		int bizcode = -1;
		scanf("%d", &bizcode);
		getchar();
		switch(bizcode){
			case 0:biz000();
				   break;
			case 1:biz001();
				   break;
			case 2:biz002();
				   break;
			case 3:biz003();
				   break;
			case 4:printf("Bye!\n");
				   return 0;
			default:break;
		}
	}
}
//add
void biz000(){
	if(connectToServer(clientfd, "127.0.0.1", 5005) == false){
		printf("error connect!\n");
		return ;
	}
	char buffer[1024];
	memset(buffer, 0, sizeof(buffer));
	char value[20];
	char tmpStr[100];
	char bizcode[10];
	memset(tmpStr, 0 ,sizeof(tmpStr));
	sprintf(bizcode, "0");
	zipXML(tmpStr, instructions[0], bizcode);
	strcat(buffer, tmpStr);
	printf("buffer:%s\n", buffer);
	printf("tmpStr:%s\n", tmpStr);
	
	for(int i = 1; i <5; i++){
		memset(value, 0, sizeof(value));
		memset(tmpStr, 0, sizeof(tmpStr));
		printf("%s:", instructions[i]);
		scanf("%s", value);
		//printf("value:%s\n", value);
		zipXML(tmpStr, instructions[i], value);
		
		strcat(buffer, tmpStr);
	}

	if( Send(clientfd, buffer, sizeof(buffer)) <= 0){
		printf("Send error!\n");
		return ;
	}
	printf("Send ok!\n");
	printf("Send buffer:%s\n", buffer);
	memset(buffer, 0, sizeof(buffer));
	if(Recv(clientfd, buffer, sizeof(buffer)) <= 0){
		printf("Recv error!\n");
		return;
	}
	printf("Recv buffer:%s\n", buffer);
	memset(value, 0, sizeof(value));
	unzipXML(buffer,  instructions[6], value);
	int retcode = atoi(value);
	if( retcode == 1){
		unzipXML(buffer, instructions[7], value);
		printf("%s\n", value);
	}else{
		printf("server error!\n");
	}
	
}

void biz001(){
	printf("Sorry, this feature is still under development..\n");
	getchar();
}

void biz002(){
	printf("Sorry, this feature is still under development..\n");
	getchar();
}

void biz003(){
	printf("Sorry, this feature is still under development..\n");
	getchar();
}

void printMenu(){
	printf("***************MENU***************\n");
	printf("0.ADD INFORMATION\n");
	printf("1.DELETE INFORMATION\n");
	printf("2.MODIFY INFORMATION\n");
	printf("3.QUERY INFORMATION\n");
	printf("4.QUIT\n");
	printf("**********************************\n");
	printf("What business do you want?\nExample:1\n");
}

