#include "tool.h"

bool unzipXML(const char* xmlbuf, const char* filedname, char* value){
	char* start = 0;
	char* end = 0;
	
	char SFName[32], EFName[32];
	memset(SFName, 0, sizeof(SFName));
	memset(EFName, 0, sizeof(EFName));

	int nameLen = strlen(filedname);
	snprintf(SFName, 31,"<%s>", filedname);
	snprintf(EFName, 31, "</%s>", filedname);
	
	start = (char*)strstr(xmlbuf, SFName);	
	end = (char*)strstr(xmlbuf, EFName);

	if((start == 0) || (end == 0)){
		return false;
	}

	int valueLen = end - start - nameLen - 2;
	
	strncpy(value, start+nameLen+2, valueLen);

	return true;
}

void zipXML(char* xmlbuf, const char* filedname, const char* value){
	char SFName[32], EFName[32];
	memset(SFName, 0, sizeof(SFName));
	memset(EFName, 0, sizeof(EFName));

	snprintf(SFName, 31, "<%s>", filedname);
	snprintf(EFName, 31, "</%s>", filedname);
	
	strcat(xmlbuf, SFName);
	strcat(xmlbuf, value);
	strcat(xmlbuf, EFName);
}

//to be improved
//can get the present time only
void getPresentTime(char* timebuf){
	time_t pretm = time(NULL);
	struct tm sttm = *localtime(&pretm);
	
	sttm.tm_year += 1900;
	sttm.tm_mon += 1;

	sprintf(timebuf, "%04u-%02u-%02u %02u:%02u:%02u", sttm.tm_year, sttm.tm_mon,
			sttm.tm_mday, sttm.tm_hour, sttm.tm_min, sttm.tm_sec);
}

