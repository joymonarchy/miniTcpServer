#ifndef TOOL_H
#define TOOL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


bool unzipXML(const char* xmlbuf, const char* filedname, char* value);

void zipXML(char* xmlbuf, const char* filedname, const char* value);

//to be improved
//can get the present time only
void getPresentTime(char* timebuf);




#endif

